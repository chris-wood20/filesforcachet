package cachet

import (
	"testing"
)

func TestAnalyseData(t *testing.T) {}
